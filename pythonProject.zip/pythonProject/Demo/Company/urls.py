from django.urls import path
from . import views

urlpatterns = [
    path('',views.registerpage),
    path('userlog/', views.user_log),
    path('adminlog/',views.admin_log),
    path('adminhome/',views.adminhome),
    path('pending/', views.pending),
    path('approve/<int:id>/', views.approve),
    path('approved/', views.approved),
    path('edit/<int:id>/', views.edit),
    path('delete/<int:id>/', views.delete),
    path('upload/', views.upload),
    path('viewimage/',views.viewimage)



]